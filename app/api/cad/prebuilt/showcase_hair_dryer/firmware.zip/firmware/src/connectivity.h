#pragma once

void connectivityInit();
void publishSensorValues(bool temperatureValid, float outletTemperatureC);
