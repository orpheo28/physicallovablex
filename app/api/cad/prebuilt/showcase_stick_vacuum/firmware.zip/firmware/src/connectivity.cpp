// Generated code — not compiled or tested
#include "connectivity.h"
#include <NimBLEDevice.h>

static NimBLECharacteristic *chr;

void connectivity_begin() {
  NimBLEDevice::init("Cordless stick vacuu");
  auto *svc = NimBLEDevice::createServer()->createService("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
  chr = svc->createCharacteristic("6e400002-b5a3-f393-e0a9-e50e24dcca9e", NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY);
  svc->start();
  NimBLEDevice::getAdvertising()->start();
}

void connectivity_loop() {}

void publishValue(const char *name, float v) {
  chr->setValue(v);
  chr->notify();
}
