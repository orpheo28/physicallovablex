#pragma once

void sensorsInit();
// Returns true only when a valid outlet temperature sample is available.
bool readOutletTemperatureC(float& temperatureC);
