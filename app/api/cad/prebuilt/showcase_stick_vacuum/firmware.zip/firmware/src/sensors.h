#pragma once

struct SensorValues {
  bool batteryProtectionOk = false;
  bool triggerPressed = false;
};

void sensorsInit();
SensorValues sensorsRead();
