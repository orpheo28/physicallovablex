#pragma once

#include <Arduino.h>

void connectivityInit();
void publishTelemetry(const String &payload);
bool transferPhoto(const uint8_t *data, size_t length);
