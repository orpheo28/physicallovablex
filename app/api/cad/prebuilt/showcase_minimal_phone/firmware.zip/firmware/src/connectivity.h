#pragma once

#include "sensors.h"

bool connectivityInit();
void connectivityPublish(const SensorSample& sample);
void connectivitySleep();
