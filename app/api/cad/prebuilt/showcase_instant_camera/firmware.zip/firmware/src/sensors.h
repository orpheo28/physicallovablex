#pragma once
void camera_init();
float camera_read();
