#pragma once
void env_init();
float env_read();
