#pragma once
#include "sensors.h"

void connectivityInit();
void connectivityPublish(const SensorValues& values);
