#pragma once

#include <Arduino.h>

struct SensorReadings {
  float lidar2dRangeM;
  float tofRangeM;
  float imuAccelX, imuAccelY, imuAccelZ;
  float imuGyroX, imuGyroY, imuGyroZ;
  float imu2AccelX, imu2AccelY, imu2AccelZ;
  float imu2GyroX, imu2GyroY, imu2GyroZ;
  float cliffRangeM;
  uint32_t encoderTicks;
  bool cameraReady;
};

bool sensorsInit();
void sensorsRead(SensorReadings &out);
