#pragma once
#include "sensors.h"

bool connectivityInit();
void connectivityPublish(const SensorSample &sample, uint32_t elapsedSeconds,
                         uint32_t sampleCount);
