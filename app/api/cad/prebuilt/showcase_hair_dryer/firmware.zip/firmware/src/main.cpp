#include <Arduino.h>
#include "connectivity.h"
#include "sensors.h"

constexpr unsigned long SAMPLE_INTERVAL_MS = 1000;

void setup() {
  sensorsInit();
  connectivityInit();
}

void loop() {
  float outletTemperatureC = 0.0f;
  const bool temperatureValid =
      readOutletTemperatureC(outletTemperatureC);

  publishSensorValues(temperatureValid, outletTemperatureC);
  delay(SAMPLE_INTERVAL_MS);  // TODO: Replace with low-power sleep if supported.
}
