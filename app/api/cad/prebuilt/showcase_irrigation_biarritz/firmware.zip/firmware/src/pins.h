#pragma once

#include <Arduino.h>

// ATmega328P-AU pin assignments; adjust for the actual board layout.
constexpr uint8_t SOIL_MOISTURE_PIN = A0;
constexpr uint8_t FLOW_PULSE_PIN = 2; // INT0

// GPIO is only a logic signal to a correctly rated external driver.
// Never connect the 6 V, ~5 W solar panel or a valve directly to an MCU pin.
constexpr uint8_t VALVE_DRIVER_PIN = 7;
