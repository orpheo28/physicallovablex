#pragma once
// Generated code — not compiled or tested
#define PIN_CAMERA 12  // TODO: from the schematic (Camera lens and image sensor module)
#define PIN_LED 13  // TODO: from the schematic (Flash assembly)
#define PIN_DISPLAY 14  // TODO: from the schematic (LCD display 2.4 inch)
