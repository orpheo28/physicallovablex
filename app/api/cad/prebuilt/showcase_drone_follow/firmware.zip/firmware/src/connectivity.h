#pragma once
#include <Arduino.h>
void connectivity_begin();
void connectivity_loop();
void publishValue(const char *name, float v);
