#pragma once
// Generated code — not compiled or tested
#define PIN_CAMERA 12  // TODO: from the schematic (Wi-Fi vision compute module)
#define PIN_CAMERA_2 13  // TODO: from the schematic (2-axis gimbal camera module)
#define PIN_GNSS 14  // TODO: from the schematic (GNSS receiver module)
#define PIN_MOTOR 15  // TODO: from the schematic (Brushless outrunner motor)
