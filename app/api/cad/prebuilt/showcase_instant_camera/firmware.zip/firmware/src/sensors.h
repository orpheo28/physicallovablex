#pragma once

#include <Arduino.h>

struct SensorSnapshot {
  bool cameraOk;
  bool batteryOk;
  int batteryRaw;
};

class Sensors {
 public:
  void init();
  SensorSnapshot read();

 private:
  bool initCamera();
  bool readCamera();
  bool initBattery();
  bool readBattery(int &raw);
};
