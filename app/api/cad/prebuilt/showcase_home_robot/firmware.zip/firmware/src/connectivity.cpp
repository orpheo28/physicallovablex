#include "connectivity.h"
#include <WiFi.h>
#include <PubSubClient.h>

namespace {
// Set these via a provisioning mechanism before deployment.
constexpr char WIFI_SSID[] = "YOUR_WIFI_SSID";
constexpr char WIFI_PASSWORD[] = "YOUR_WIFI_PASSWORD";
constexpr char MQTT_HOST[] = "192.168.1.10";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char CLIENT_ID[] = "toy-tidying-robot";
constexpr char TELEMETRY_TOPIC[] = "toy-robot/telemetry";
constexpr char COMMAND_TOPIC[] = "toy-robot/command";
WiFiClient net;
PubSubClient mqtt(net);
CommandHandler commandHandler = nullptr;
unsigned long lastReconnectAttempt = 0;
void onMessage(char *, byte *payload, unsigned int length) {
  if (!commandHandler) return;
  char message[128];
  const unsigned int n = min(length, static_cast<unsigned int>(sizeof(message) - 1));
  memcpy(message, payload, n); message[n] = '\0';
  commandHandler(message);
}
bool reconnect() {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (mqtt.connect(CLIENT_ID)) { mqtt.subscribe(COMMAND_TOPIC); return true; }
  return false;
}
}

void connectivityInit(CommandHandler handler) {
  commandHandler = handler;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMessage);
}

void connectivityLoop() {
  if (!mqtt.connected() && millis() - lastReconnectAttempt > 5000) {
    lastReconnectAttempt = millis(); reconnect();
  }
  mqtt.loop();
}

void publishTelemetry(const SensorReadings &r) {
  if (!mqtt.connected()) return;
  char payload[512];
  snprintf(payload, sizeof(payload),
    "{\"lidar2d_m\":%.3f,\"tof_m\":%.3f,\"imu_accel\":[%.3f,%.3f,%.3f],\"imu_gyro\":[%.3f,%.3f,%.3f],\"imu2_accel\":[%.3f,%.3f,%.3f],\"imu2_gyro\":[%.3f,%.3f,%.3f],\"cliff_m\":%.3f,\"encoder_ticks\":%lu,\"camera_ready\":%s}",
    r.lidar2dRangeM, r.tofRangeM, r.imuAccelX, r.imuAccelY, r.imuAccelZ,
    r.imuGyroX, r.imuGyroY, r.imuGyroZ, r.imu2AccelX, r.imu2AccelY, r.imu2AccelZ,
    r.imu2GyroX, r.imu2GyroY, r.imu2GyroZ, r.cliffRangeM,
    static_cast<unsigned long>(r.encoderTicks), r.cameraReady ? "true" : "false");
  mqtt.publish(TELEMETRY_TOPIC, payload);
}
