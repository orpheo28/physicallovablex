#pragma once
#include <Arduino.h>

struct SensorSample {
  uint8_t heartRateBpm;
  int16_t ax, ay, az;
  int16_t gx, gy, gz;
};

bool sensorsInit();
bool sensorsRead(SensorSample &sample);
