#include <Arduino.h>
#include "sensors.h"
#include "connectivity.h"

static uint32_t startedAt;
static uint32_t samples;
static constexpr uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);
  sensorsInit();
  connectivityInit();
  startedAt = millis();
}

void loop() {
  SensorSample sample{};
  if (sensorsRead(sample)) {
    ++samples;
    connectivityPublish(sample, (millis() - startedAt) / 1000, samples);
  }
  delay(SAMPLE_PERIOD_MS); // TODO: replace with supported low-power sleep/wakeup.
}
