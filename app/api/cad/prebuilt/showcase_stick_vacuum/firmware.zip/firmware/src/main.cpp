// Generated code — not compiled or tested
#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

static const uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);

  pinMode(PIN_MOTOR, OUTPUT);  // High-speed BLDC vacuum motor assembly
  pinMode(PIN_LED, OUTPUT);  // Status LED
  connectivity_begin();
}

void loop() {
  connectivity_loop();

  delay(SAMPLE_PERIOD_MS);  // TODO: light/deep sleep for battery products
}
