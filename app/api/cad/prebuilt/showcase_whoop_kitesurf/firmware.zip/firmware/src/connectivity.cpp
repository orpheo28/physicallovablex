#include "connectivity.h"
#include <ArduinoBLE.h>

static BLEService heartRateService("180D");
static BLECharacteristic heartRateChar("2A37", BLERead | BLENotify, 2);
static BLEService bandService("7d2a0001-8c1d-4b9e-a753-6f3c0a100000");
static BLECharacteristic motionChar("7d2a0002-8c1d-4b9e-a753-6f3c0a100000", BLERead | BLENotify, 12);
static BLECharacteristic sessionChar("7d2a0003-8c1d-4b9e-a753-6f3c0a100000", BLERead | BLENotify, 8);

bool connectivityInit() {
  if (!BLE.begin()) return false;
  BLE.setLocalName("Kitesurf Recovery Band");
  BLE.setAdvertisedService(heartRateService);
  heartRateService.addCharacteristic(heartRateChar);
  bandService.addCharacteristic(motionChar);
  bandService.addCharacteristic(sessionChar);
  BLE.addService(heartRateService);
  BLE.addService(bandService);
  BLE.advertise();
  return true;
}

void connectivityPublish(const SensorSample &s, uint32_t elapsedSeconds,
                         uint32_t sampleCount) {
  uint8_t hr[2] = {0x00, s.heartRateBpm}; // 8-bit heart-rate value
  uint8_t motion[12];
  const int16_t axes[6] = {s.ax, s.ay, s.az, s.gx, s.gy, s.gz};
  for (unsigned i = 0; i < 6; ++i) {
    motion[2 * i] = (uint8_t)axes[i];
    motion[2 * i + 1] = (uint8_t)(axes[i] >> 8);
  }
  uint8_t session[8];
  const uint32_t values[2] = {elapsedSeconds, sampleCount};
  for (unsigned v = 0; v < 2; ++v)
    for (unsigned b = 0; b < 4; ++b)
      session[4 * v + b] = (uint8_t)(values[v] >> (8 * b));
  heartRateChar.writeValue(hr, sizeof(hr));
  motionChar.writeValue(motion, sizeof(motion));
  sessionChar.writeValue(session, sizeof(session));
  BLE.poll();
}
