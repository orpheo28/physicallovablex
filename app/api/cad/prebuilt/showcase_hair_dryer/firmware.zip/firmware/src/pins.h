#pragma once
// Generated code — not compiled or tested
#define PIN_ENV 12  // TODO: from the schematic (NTC outlet temperature sensor)
#define PIN_MOTOR 13  // TODO: from the schematic (AC universal motor with fan impeller)
#define PIN_MOTOR_1 14  // TODO: from the schematic (Motor and heater control switches)
