// Generated code — not compiled or tested
#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

static const uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);
  moisture_init();

  connectivity_begin();
}

void loop() {
  connectivity_loop();
  publishValue("moisture", moisture_read());
  delay(SAMPLE_PERIOD_MS);  // TODO: light/deep sleep for battery products
}
