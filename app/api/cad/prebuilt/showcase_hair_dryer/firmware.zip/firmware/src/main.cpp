// Generated code — not compiled or tested
#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

static const uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);
  env_init();
  pinMode(PIN_MOTOR, OUTPUT);  // AC universal motor with fan impeller
  pinMode(PIN_MOTOR_1, OUTPUT);  // Motor and heater control switches
  connectivity_begin();
}

void loop() {
  connectivity_loop();
  publishValue("env", env_read());
  delay(SAMPLE_PERIOD_MS);  // TODO: light/deep sleep for battery products
}
