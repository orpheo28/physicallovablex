// Generated code — not compiled or tested
#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

static const uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);
  camera_init();
  lidar_init();
  lidar_2_init();
  imu_init();
  pinMode(PIN_MOTOR, OUTPUT);  // Brushed DC gearmotor with encoder
  connectivity_begin();
}

void loop() {
  connectivity_loop();
  publishValue("camera", camera_read());
  publishValue("lidar", lidar_read());
  publishValue("lidar_2", lidar_2_read());
  publishValue("imu", imu_read());
  delay(SAMPLE_PERIOD_MS);  // TODO: light/deep sleep for battery products
}
