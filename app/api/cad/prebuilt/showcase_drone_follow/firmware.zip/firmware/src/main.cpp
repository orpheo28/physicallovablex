#include <Arduino.h>
#include "sensors.h"
#include "connectivity.h"

constexpr uint32_t SamplePeriodMs = 50;

void setup() {
  Serial.begin(115200);
  Sensors::init();
  Connectivity::init();
}

void loop() {
  const Sensors::Sample sample = Sensors::read();
  Connectivity::publish(sample);
  delay(SamplePeriodMs);
}
