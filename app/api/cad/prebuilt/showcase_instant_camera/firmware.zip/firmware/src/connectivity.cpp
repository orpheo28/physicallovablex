#include "connectivity.h"
#include <WiFi.h>

#ifndef WIFI_SSID
#define WIFI_SSID ""
#endif
#ifndef WIFI_PASSWORD
#define WIFI_PASSWORD ""
#endif

void connectivityInit() {
  if (strlen(WIFI_SSID) == 0) return;  // Configure credentials at build time to enable Wi-Fi.
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void publishTelemetry(const String &payload) {
  // Local diagnostic publication; TODO: send to the chosen service when connected.
  Serial.println(payload);
}

bool transferPhoto(const uint8_t *data, size_t length) {
  // TODO: Add an authenticated transfer endpoint and camera image format handling.
  (void)data;
  (void)length;
  return false;
}
