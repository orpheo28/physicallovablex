// Generated code — not compiled or tested
#include <WiFi.h>
#include <PubSubClient.h>
#include "connectivity.h"

static const char *WIFI_SSID = "TODO";
static const char *WIFI_PASS = "TODO";
static const char *MQTT_HOST = "TODO";
static WiFiClient net;
static PubSubClient mqtt(net);

void connectivity_begin() {
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  mqtt.setServer(MQTT_HOST, 1883);
}

void connectivity_loop() {
  if (WiFi.status() == WL_CONNECTED && !mqtt.connected()) mqtt.connect("toy_tidying_home_robot");
  mqtt.loop();
}

void publishValue(const char *name, float v) {
  char topic[64];
  snprintf(topic, sizeof topic, "toy_tidying_home_robot/%s", name);
  char payload[16];
  dtostrf(v, 0, 3, payload);
  mqtt.publish(topic, payload);
}
