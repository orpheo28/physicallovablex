#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

namespace {
void handleCommand(const char *payload) {
  // Minimal safe placeholder: command protocol and motor driver are product-specific.
  // TODO: validate authenticated commands and implement bounded motor control.
  if (strcmp(payload, "stop") == 0) {
    digitalWrite(PIN_MOTOR_LEFT, LOW);
    digitalWrite(PIN_MOTOR_RIGHT, LOW);
  }
}
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_MOTOR_LEFT, OUTPUT);
  pinMode(PIN_MOTOR_RIGHT, OUTPUT);
  digitalWrite(PIN_MOTOR_LEFT, LOW);
  digitalWrite(PIN_MOTOR_RIGHT, LOW);
  sensorsInit();
  connectivityInit(handleCommand);
}

void loop() {
  connectivityLoop();
  SensorReadings readings{};
  sensorsRead(readings);
  publishTelemetry(readings);
  delay(1000); // TODO: replace with a non-blocking schedule for responsive control.
}
