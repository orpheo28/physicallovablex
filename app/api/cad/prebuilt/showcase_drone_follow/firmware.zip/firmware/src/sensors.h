#pragma once
void camera_init();
float camera_read();
void camera_2_init();
float camera_2_read();
void gnss_init();
float gnss_read();
