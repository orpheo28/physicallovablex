#pragma once

// Assign pins and buses from the ODM schematic; no pinout is assumed here.
// Camera modules and display/touch assembly use SPI per the product BOM.
// Cellular/Wi-Fi/BLE ODM modem uses UART; configure its UART in the board layer.
// Audio transducers and microphones use PWM-capable board-specific interfaces.
