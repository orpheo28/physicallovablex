#pragma once

// Set these to the board's actual Arduino pin numbers before building.
#ifndef BAND_SDA_PIN
#define BAND_SDA_PIN 0
#endif
#ifndef BAND_SCL_PIN
#define BAND_SCL_PIN 1
#endif

// Sensor addresses are intentionally not used by the stub drivers; confirm
// board wiring and sensor address configuration when implementing the drivers.
