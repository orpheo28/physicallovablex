#pragma once

#include "sensors.h"

void connectivityInit();
void connectivityPoll();
bool connectivityPublish(const SensorReadings &readings);
