#pragma once
void moisture_init();
float moisture_read();
