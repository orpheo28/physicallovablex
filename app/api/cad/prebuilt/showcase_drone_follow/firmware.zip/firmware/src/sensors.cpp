// Generated code — not compiled or tested
#include "sensors.h"

// Wi-Fi vision compute module (SPI)
void camera_init() { /* TODO: vendor library begin() */ }
float camera_read() { return 0.0f; /* TODO */ }

// 2-axis gimbal camera module (SPI)
void camera_2_init() { /* TODO: vendor library begin() */ }
float camera_2_read() { return 0.0f; /* TODO */ }

// GNSS receiver module (UART)
void gnss_init() { /* TODO: vendor library begin() */ }
float gnss_read() { return 0.0f; /* TODO */ }
