// Generated code — not compiled or tested
#include "sensors.h"

// no sensors
