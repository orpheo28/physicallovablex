#include "connectivity.h"
#include "pins.h"
#include <Arduino.h>
#include <SPI.h>

namespace Connectivity {
void init() {
  // TODO: Bind the documented 2.4 GHz control-link radio and its verified interface.
  // TODO: Configure Wi-Fi video transport on the vision module over its documented SPI API.
  // No radio, camera protocol, credentials, or SPI pin mapping is assumed.
}

void publish(const Sensors::Sample &sample) {
  // Skeleton telemetry only; replace with bounded, authenticated link messages.
  Serial.print("t_ms="); Serial.print(sample.timestampMs);
  Serial.print(" imu="); Serial.print(sample.imuValid ? 1 : 0);
  Serial.print(" gnss="); Serial.print(sample.gnssValid ? 1 : 0);
  Serial.print(" lat="); Serial.print(sample.latitudeDeg, 6);
  Serial.print(" lon="); Serial.println(sample.longitudeDeg, 6);
  // TODO: Publish sample over the control link; keep Wi-Fi video handling separate.
}
}
