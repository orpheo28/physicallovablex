#pragma once
// Generated code — not compiled or tested
#define PIN_MOISTURE 12  // TODO: from the schematic (Capacitive soil-moisture probe module, analog output)
