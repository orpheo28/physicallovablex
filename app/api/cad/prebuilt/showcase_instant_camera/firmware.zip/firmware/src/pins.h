#pragma once

// Example GPIO assignments only; verify against the exact ESP32-S3 module and board.
#define PIN_SPI_SCK   12
#define PIN_SPI_MISO  13
#define PIN_SPI_MOSI  11
#define PIN_CAMERA_CS 10
#define PIN_BATTERY_CS 9
#define PIN_LCD_CS    7
#define PIN_FLASH     8
