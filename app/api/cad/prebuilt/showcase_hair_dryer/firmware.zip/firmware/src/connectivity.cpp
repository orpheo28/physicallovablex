#include "connectivity.h"

void connectivityInit() {
  // TODO: Initialize the product's connectivity transport.
}

void publishSensorValues(bool temperatureValid, float outletTemperatureC) {
  (void)temperatureValid;
  (void)outletTemperatureC;
  // TODO: Publish the sample through the selected connectivity transport.
}
