#include "connectivity.h"
#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>

namespace {
// Set these for the deployment; use protected provisioning for production.
const char *wifiSsid = "YOUR_WIFI_SSID";
const char *wifiPassword = "YOUR_WIFI_PASSWORD";
const char *mqttHost = "192.0.2.1";
constexpr uint16_t mqttPort = 1883;
WiFiClient networkClient;
PubSubClient mqtt(networkClient);

void onMqttMessage(char *topic, byte *payload, unsigned int length) {
  (void)payload;
  (void)length;
  // TODO: Parse and validate schedule commands; do not actuate a valve from
  // unauthenticated/unvalidated input. Define a safe schedule format first.
  Serial.print(F("MQTT command on "));
  Serial.println(topic);
}
}

void connectivityInit() {
  WiFi.begin(wifiSsid, wifiPassword);
  mqtt.setServer(mqttHost, mqttPort);
  mqtt.setCallback(onMqttMessage);
  // TODO: Confirm the chosen external Wi-Fi hardware/library is compatible
  // with the ATmega328P board and available RAM before deployment.
}

void connectivityPoll() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!mqtt.connected()) {
    if (mqtt.connect("smart-garden-irrigation")) {
      mqtt.subscribe("garden/irrigation/schedule");
    }
  }
  if (mqtt.connected()) mqtt.loop();
}

bool connectivityPublish(const SensorReadings &readings) {
  if (WiFi.status() != WL_CONNECTED || !mqtt.connected()) return false;
  char soil[12];
  char flow[16];
  snprintf(soil, sizeof(soil), "%u", readings.soilRaw);
  snprintf(flow, sizeof(flow), "%lu", (unsigned long)readings.flowPulses);
  const bool soilOk = mqtt.publish("garden/soil/raw", soil);
  const bool flowOk = mqtt.publish("garden/flow/pulses", flow);
  return soilOk && flowOk;
}
