#pragma once

#include <Arduino.h>
#include "sensors.h"

using CommandHandler = void (*)(const char *payload);
void connectivityInit(CommandHandler handler);
void connectivityLoop();
void publishTelemetry(const SensorReadings &readings);
