#include "sensors.h"
#include "pins.h"
#include <Wire.h>
#include <SPI.h>

namespace {
// Replace each stub with the relevant device library/transport implementation.
bool initRgbCamera() { SPI.begin(PIN_CAMERA_SCK, PIN_CAMERA_MISO, PIN_CAMERA_MOSI, PIN_CAMERA_CS); pinMode(PIN_CAMERA_CS, OUTPUT); digitalWrite(PIN_CAMERA_CS, HIGH); return false; /* TODO: initialize SPI RGB camera; no register map assumed. */ }
bool initLidar2d() { return false; /* TODO: initialize 2D lidar on I2C. */ }
bool initTof() { return false; /* TODO: initialize ToF sensor on I2C. */ }
bool initImu() { return false; /* TODO: initialize six-axis IMU on I2C. */ }
bool initImu2() { return false; /* TODO: initialize second six-axis IMU on I2C. */ }
bool initCliffTof() { return false; /* TODO: initialize VL53L1X cliff sensor using its driver. */ }
void readLidar2d(float &) { /* TODO: read range in meters. */ }
void readTof(float &) { /* TODO: read range in meters. */ }
void readImu(float &, float &, float &, float &, float &, float &) { /* TODO: read acceleration and angular rate. */ }
void readImu2(float &, float &, float &, float &, float &, float &) { /* TODO: read second IMU. */ }
void readCliffTof(float &) { /* TODO: read cliff range in meters. */ }
volatile uint32_t encoderTicks = 0;
void IRAM_ATTR onEncoderEdge() { ++encoderTicks; }
}

bool sensorsInit() {
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  pinMode(PIN_MOTOR_ENCODER, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_MOTOR_ENCODER), onEncoderEdge, CHANGE);
  const bool camera = initRgbCamera();
  initLidar2d(); initTof(); initImu(); initImu2(); initCliffTof();
  return camera;
}

void sensorsRead(SensorReadings &out) {
  out = {};
  readLidar2d(out.lidar2dRangeM);
  readTof(out.tofRangeM);
  readImu(out.imuAccelX, out.imuAccelY, out.imuAccelZ, out.imuGyroX, out.imuGyroY, out.imuGyroZ);
  readImu2(out.imu2AccelX, out.imu2AccelY, out.imu2AccelZ, out.imu2GyroX, out.imu2GyroY, out.imu2GyroZ);
  readCliffTof(out.cliffRangeM);
  noInterrupts(); out.encoderTicks = encoderTicks; interrupts();
  out.cameraReady = false; // TODO: set from the camera driver's status.
}
