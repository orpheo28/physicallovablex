#include "connectivity.h"
#include "pins.h"
#include <Arduino.h>

bool connectivityInit() {
  // TODO: Bind the ODM modem UART using schematic-defined pins and settings.
  // Implement LTE, Wi-Fi, and BLE through the modem's documented interface;
  // no modem protocol or command set is assumed by this skeleton.
  return true;
}

void connectivityPublish(const SensorSample& sample) {
  // TODO: Publish valid samples over the configured ODM connectivity service.
  (void)sample;
}

void connectivitySleep() {
  // TODO: Request modem low-power state using the documented ODM API.
}
