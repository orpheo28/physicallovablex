// Generated code — not compiled or tested
#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

static const uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);
  camera_init();
  camera_2_init();
  gnss_init();
  pinMode(PIN_MOTOR, OUTPUT);  // Brushless outrunner motor
  connectivity_begin();
}

void loop() {
  connectivity_loop();
  publishValue("camera", camera_read());
  publishValue("camera_2", camera_2_read());
  publishValue("gnss", gnss_read());
  delay(SAMPLE_PERIOD_MS);  // TODO: light/deep sleep for battery products
}
