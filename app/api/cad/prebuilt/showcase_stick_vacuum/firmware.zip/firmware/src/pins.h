#pragma once

// Set these to pins appropriate for the selected STM32 board. -1 disables a pin.
constexpr int PIN_BATTERY_PROTECTION = -1; // Protection/status output from pack
constexpr int PIN_TRIGGER = -1;            // Pistol-grip trigger switch
constexpr int PIN_STATUS_LED = -1;

// BLDC motors require a suitable driver/controller; never connect a motor directly
// to an MCU GPIO. Driver wiring and control are intentionally not implemented here.
