#pragma once

// Adjust to match the selected ESP32-S3 module and wiring.
constexpr int PIN_I2C_SDA = 8;
constexpr int PIN_I2C_SCL = 9;
constexpr int PIN_CAMERA_CS = 10;
constexpr int PIN_CAMERA_SCK = 12;
constexpr int PIN_CAMERA_MISO = 13;
constexpr int PIN_CAMERA_MOSI = 11;
constexpr int PIN_MOTOR_LEFT = 4;
constexpr int PIN_MOTOR_RIGHT = 5;
constexpr int PIN_MOTOR_ENCODER = 6;
