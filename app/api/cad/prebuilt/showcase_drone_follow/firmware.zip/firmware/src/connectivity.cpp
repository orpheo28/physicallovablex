// Generated code — not compiled or tested
#include "connectivity.h"

void connectivity_begin() {}
void connectivity_loop() {}
void publishValue(const char *name, float v) {
  Serial.printf("%s=%.3f\n", name, v);
}
