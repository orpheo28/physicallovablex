#pragma once

#include <Arduino.h>

namespace Sensors {
struct Sample {
  uint32_t timestampMs = 0;
  bool imuValid = false;
  bool gnssValid = false;
  float latitudeDeg = 0.0f;
  float longitudeDeg = 0.0f;
  uint8_t satellites = 0;
};

void init();
Sample read();
}
