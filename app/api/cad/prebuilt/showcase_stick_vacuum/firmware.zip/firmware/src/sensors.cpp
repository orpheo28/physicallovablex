#include "sensors.h"
#include "pins.h"
#include <Arduino.h>

void sensorsInit() {
  if (PIN_BATTERY_PROTECTION >= 0) pinMode(PIN_BATTERY_PROTECTION, INPUT);
  if (PIN_TRIGGER >= 0) pinMode(PIN_TRIGGER, INPUT_PULLUP);
  // TODO: Confirm pack signal polarity, electrical levels, and required conditioning.
  // TODO: Add sensor-specific initialization when hardware interfaces are defined.
}

SensorValues sensorsRead() {
  SensorValues values;
  // TODO: Confirm protection signal polarity with the battery-pack documentation.
  if (PIN_BATTERY_PROTECTION >= 0)
    values.batteryProtectionOk = digitalRead(PIN_BATTERY_PROTECTION) == HIGH;
  // Assumes an active-low trigger with an external or internal pull-up; verify on hardware.
  if (PIN_TRIGGER >= 0)
    values.triggerPressed = digitalRead(PIN_TRIGGER) == LOW;
  // TODO: Add sensor reads once the hardware interfaces and data formats are specified.
  return values;
}
