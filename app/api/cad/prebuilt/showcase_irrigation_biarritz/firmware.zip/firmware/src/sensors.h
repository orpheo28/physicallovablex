#pragma once

#include <Arduino.h>

struct SensorReadings {
  uint16_t soilRaw;
  uint32_t flowPulses;
};

void sensorsInit();
SensorReadings sensorsRead();
