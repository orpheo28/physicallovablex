#include <Arduino.h>
#include <Wire.h>
#include "sensors.h"

void sensorsInit() {
  Wire.begin();
  // TODO: Initialize the outlet NTC sensor using its supplied device details.
  // Do not assume a register map or I2C address here.
}

bool readOutletTemperatureC(float& temperatureC) {
  (void)temperatureC;
  // TODO: Read and convert the sensor according to its datasheet.
  // No register map, address, or conversion formula is assumed.
  return false;
}
