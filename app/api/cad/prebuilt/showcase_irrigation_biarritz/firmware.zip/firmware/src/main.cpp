#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

constexpr unsigned long SAMPLE_INTERVAL_MS = 10000;

void setup() {
  Serial.begin(9600);
  sensorsInit();
  // Output controls only an external driver; no load may connect directly.
  pinMode(VALVE_DRIVER_PIN, OUTPUT);
  digitalWrite(VALVE_DRIVER_PIN, LOW);
  connectivityInit();
}

void loop() {
  connectivityPoll();
  const SensorReadings readings = sensorsRead();
  connectivityPublish(readings);
  // TODO: Replace with a power-safe sleep strategy compatible with the Wi-Fi
  // module and required flow-pulse capture; this delay is a skeleton placeholder.
  delay(SAMPLE_INTERVAL_MS);
}
