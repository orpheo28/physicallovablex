#include "sensors.h"
#include "pins.h"
#include <SPI.h>

namespace Sensors {
void init() {
  // TODO: Initialize the board IMU using its identified driver and verified wiring.
  // TODO: Initialize GNSS UART and select baud/protocol from the module documentation.
  // TODO: Initialize camera/gimbal SPI devices after confirming buses and chip selects.
  // No register maps, protocols, or pin assignments are assumed here.
}

Sample read() {
  Sample s;
  s.timestampMs = millis();
  // TODO: Read IMU and GNSS; set validity only after validated fresh measurements.
  // TODO: Camera and gimbal acquisition belong in their documented device drivers.
  return s;
}
}
