#pragma once
// Generated code — not compiled or tested
#define PIN_MOTOR 12  // TODO: from the schematic (High-speed BLDC vacuum motor assembly)
#define PIN_LED 13  // TODO: from the schematic (Status LED)
