#include <Arduino.h>
#include "sensors.h"
#include "connectivity.h"

static Sensors sensors;
static constexpr uint32_t SAMPLE_INTERVAL_MS = 5000;

void setup() {
  Serial.begin(115200);
  sensors.init();
  connectivityInit();
}

void loop() {
  const SensorSnapshot sample = sensors.read();
  String payload = "{\"camera_ok\":";
  payload += sample.cameraOk ? "true" : "false";
  payload += ",\"battery_ok\":";
  payload += sample.batteryOk ? "true" : "false";
  payload += ",\"battery_raw\":";
  payload += String(sample.batteryRaw);
  payload += "}";
  publishTelemetry(payload);
  delay(SAMPLE_INTERVAL_MS);  // Sleep between samples; replace with low-power sleep if needed.
}
