// Generated code — not compiled or tested
#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

static const uint32_t SAMPLE_PERIOD_MS = 1000;

void setup() {
  Serial.begin(115200);
  camera_init();
  pinMode(PIN_LED, OUTPUT);  // Flash assembly
  pinMode(PIN_DISPLAY, OUTPUT);  // LCD display 2.4 inch
  connectivity_begin();
}

void loop() {
  connectivity_loop();
  publishValue("camera", camera_read());
  delay(SAMPLE_PERIOD_MS);  // TODO: light/deep sleep for battery products
}
