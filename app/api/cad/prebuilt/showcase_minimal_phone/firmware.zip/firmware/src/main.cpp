#include <Arduino.h>
#include "sensors.h"
#include "connectivity.h"

namespace {
constexpr unsigned long kSamplePeriodMs = 1000;
}

void setup() {
  Serial.begin(115200);
  sensorsInit();
  connectivityInit();
}

void loop() {
  const SensorSample sample = sensorsRead();
  connectivityPublish(sample);
  connectivitySleep();
  // TODO: Replace delay with the ODM MCU's low-power sleep/wake mechanism.
  delay(kSamplePeriodMs);
}
