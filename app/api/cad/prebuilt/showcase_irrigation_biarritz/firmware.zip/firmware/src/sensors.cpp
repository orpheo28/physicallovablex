#include "sensors.h"
#include "pins.h"

namespace {
volatile uint32_t flowPulseCount = 0;
void onFlowPulse() { ++flowPulseCount; }
}

void sensorsInit() {
  pinMode(SOIL_MOISTURE_PIN, INPUT);
  pinMode(FLOW_PULSE_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(FLOW_PULSE_PIN), onFlowPulse, FALLING);
  // TODO: Add sensor-specific initialization after confirming the sensor models.
}

SensorReadings sensorsRead() {
  SensorReadings result{};
  result.soilRaw = analogRead(SOIL_MOISTURE_PIN);
  noInterrupts();
  result.flowPulses = flowPulseCount;
  flowPulseCount = 0;
  interrupts();
  // TODO: Calibrate moisture readings and convert flow pulses to engineering units.
  return result;
}
