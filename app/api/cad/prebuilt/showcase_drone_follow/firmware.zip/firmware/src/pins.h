#pragma once

// Replace with verified carrier-board pin assignments before enabling hardware.
// -1 means unassigned; drivers must not use an unassigned pin.
namespace Pins {
constexpr int GnssRx = -1;
constexpr int GnssTx = -1;
constexpr int CameraSpiCs = -1;
constexpr int GimbalSpiCs = -1;
constexpr int Camera4kSpiCs = -1;
constexpr int MotorOut = -1;
constexpr int Motor1404Out = -1;
}
