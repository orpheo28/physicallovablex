#pragma once

struct SensorSample {
  bool valid;
  float value;
};

// Initialize available sensor/peripheral interfaces. Returns false if unavailable.
bool sensorsInit();
// Read one sample; invalid samples are marked valid=false.
SensorSample sensorsRead();
