#include "sensors.h"
#include "pins.h"
#include <SPI.h>

void Sensors::init() {
  SPI.begin(PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI);
  pinMode(PIN_CAMERA_CS, OUTPUT);
  pinMode(PIN_BATTERY_CS, OUTPUT);
  digitalWrite(PIN_CAMERA_CS, HIGH);
  digitalWrite(PIN_BATTERY_CS, HIGH);
  pinMode(PIN_FLASH, OUTPUT);
  digitalWrite(PIN_FLASH, LOW);
  initCamera();
  initBattery();
}

bool Sensors::initCamera() {
  // TODO: Initialize the camera/image-sensor module using its documented interface.
  // No register map or module-specific protocol is assumed here.
  return false;
}

bool Sensors::readCamera() {
  // TODO: Acquire/check camera data using the selected module's documented protocol.
  return false;
}

bool Sensors::initBattery() {
  // TODO: Initialize the battery monitor/pack interface per its documentation.
  return false;
}

bool Sensors::readBattery(int &raw) {
  // TODO: Read a documented battery measurement; raw is invalid on failure.
  (void)raw;
  return false;
}

SensorSnapshot Sensors::read() {
  SensorSnapshot snapshot = {false, false, 0};
  snapshot.cameraOk = readCamera();
  snapshot.batteryOk = readBattery(snapshot.batteryRaw);
  return snapshot;
}
