#pragma once

// Arduino Uno PWM-capable outputs; hardware routing must be verified.
constexpr uint8_t MOTOR_PWM_PIN = 3;
constexpr uint8_t MOTOR_HEATER_PWM_PIN = 5;
constexpr uint8_t BLDC_FAN_PWM_PIN = 6;

// Uno I2C pins are A4 (SDA) and A5 (SCL).
