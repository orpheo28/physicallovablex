#include "connectivity.h"
#include <Arduino.h>

void connectivityInit() {
  // TODO: Initialize an optional BLE app link after selecting a supported BLE stack.
}

void connectivityPublish(const SensorValues& values) {
  // Local serial telemetry keeps the skeleton observable; no BLE protocol is defined.
  Serial.print("battery_protection_ok=");
  Serial.print(values.batteryProtectionOk ? 1 : 0);
  Serial.print(",trigger_pressed=");
  Serial.println(values.triggerPressed ? 1 : 0);
  // TODO: Forward values to the app when a BLE service/protocol is specified.
}
