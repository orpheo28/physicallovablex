#pragma once
// Generated code — not compiled or tested
#define PIN_CAMERA 12  // TODO: from the schematic (RGB camera module)
#define PIN_LIDAR 13  // TODO: from the schematic (2D lidar module)
#define PIN_LIDAR_2 14  // TODO: from the schematic (Time-of-flight distance sensor)
#define PIN_IMU 15  // TODO: from the schematic (Six-axis IMU)
#define PIN_MOTOR 16  // TODO: from the schematic (Brushed DC gearmotor with encoder)
