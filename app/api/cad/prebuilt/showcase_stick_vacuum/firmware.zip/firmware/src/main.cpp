#include <Arduino.h>
#include "pins.h"
#include "sensors.h"
#include "connectivity.h"

constexpr unsigned long SAMPLE_INTERVAL_MS = 100;

void setup() {
  Serial.begin(115200);
  if (PIN_STATUS_LED >= 0) {
    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_STATUS_LED, LOW);
  }
  sensorsInit();
  connectivityInit();
}

void loop() {
  const SensorValues values = sensorsRead();
  connectivityPublish(values);
  // TODO: Define safe LED behavior and motor-driver controls after hardware review.
  delay(SAMPLE_INTERVAL_MS); // Sleep between samples; use a low-power sleep API if available.
}
