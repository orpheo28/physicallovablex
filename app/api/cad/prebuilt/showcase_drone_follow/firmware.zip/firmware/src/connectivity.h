#pragma once

#include "sensors.h"

namespace Connectivity {
void init();
void publish(const Sensors::Sample &sample);
}
