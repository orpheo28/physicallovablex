// Generated code — not compiled or tested
#include "sensors.h"

// NTC outlet temperature sensor (I2C)
void env_init() { /* TODO: vendor library begin() */ }
float env_read() { return 0.0f; /* TODO */ }
